package co.com.colfondos.documentManagerBe.service;


import co.com.colfondos.documentManagerBe.model.Images;
import java.util.List;

public interface IImageService {
  List<Images> saveListImages(List<Images> images);
}
