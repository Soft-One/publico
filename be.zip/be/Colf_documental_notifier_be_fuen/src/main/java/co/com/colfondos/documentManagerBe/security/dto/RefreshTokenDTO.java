package co.com.colfondos.documentManagerBe.security.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RefreshTokenDTO {
    private String username;
    private String refreshToken;
}
