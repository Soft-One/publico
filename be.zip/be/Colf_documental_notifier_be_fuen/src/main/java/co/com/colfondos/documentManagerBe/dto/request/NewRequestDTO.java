package co.com.colfondos.documentManagerBe.dto.request;

import co.com.colfondos.documentManagerBe.dto.ImagesDTO;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class NewRequestDTO {
    private String documentNumber;
    private int documentType;
    private String firstName;
    private List<ImagesDTO> images;
    private String lastName;
    private String middleName;
    private String requestNumber;
    private String surName;
}
