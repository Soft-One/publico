package co.com.colfondos.documentManagerBe.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "SOLICITUD")
@Getter
@Setter
public class Request {

  @Id
  @GeneratedValue(strategy = GenerationType.TABLE, generator = "book_generator")
  @TableGenerator(name="book_generator", table="id_generator", initialValue = 1180100)
  @Column(name = "codsol")
  private long codsol;

  @JsonIgnore
  @ManyToOne(cascade =  CascadeType.ALL,fetch=FetchType.EAGER)
  @JoinColumn(name = "codigo")
  private Customer codigo;

  @JsonIgnore
  @Column(name = "fechaCreacion")
  private java.sql.Timestamp fechaCreacion;

  @OneToOne
  @JoinColumn(name = "estadopo")
  private StatesCfg estadopo;

  @OneToOne
  @JoinColumn(name = "estadoce")
  private StatesCfg estadoce;

  @Column(name = "numeroSolicitud")
  private String numeroSolicitud;

  @OneToMany(mappedBy="codsol",cascade =  CascadeType.ALL, fetch = FetchType.LAZY)
  private List<Images> images;



}
