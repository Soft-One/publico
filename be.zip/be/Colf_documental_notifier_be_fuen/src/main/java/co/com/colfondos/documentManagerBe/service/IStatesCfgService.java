package co.com.colfondos.documentManagerBe.service;


import co.com.colfondos.documentManagerBe.dto.StatesCfgDTO;

public interface IStatesCfgService {

  StatesCfgDTO getById(Integer id);
}
