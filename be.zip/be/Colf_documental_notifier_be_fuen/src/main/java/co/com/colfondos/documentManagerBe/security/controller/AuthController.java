package co.com.colfondos.documentManagerBe.security.controller;


import co.com.colfondos.documentManagerBe.dto.response.MessageDTO;
import co.com.colfondos.documentManagerBe.security.dto.*;
import co.com.colfondos.documentManagerBe.security.entity.User;
import co.com.colfondos.documentManagerBe.security.entity.UserPrincipal;
import co.com.colfondos.documentManagerBe.security.enums.RolName;
import co.com.colfondos.documentManagerBe.security.jwt.JwtProvider;
import co.com.colfondos.documentManagerBe.security.service.RolService;
import co.com.colfondos.documentManagerBe.security.service.UserDetailsServiceImpl;
import co.com.colfondos.documentManagerBe.security.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.*;

import static org.springframework.http.ResponseEntity.ok;

@RestController
@RequestMapping("/auth")
@CrossOrigin
public class AuthController {

    @Autowired
    PasswordEncoder passwordEncoder;

    @Autowired
    AuthenticationManager authenticationManager;

    @Autowired
    UserDetailsServiceImpl userDetailsService;

    @Autowired
    UserService userService;

    @Autowired
    RolService rolService;

    @Autowired
    JwtProvider jwtProvider;

    @PostMapping("/nuevo")
    public ResponseEntity<?> nuevo(@Valid @RequestBody NewUserDto newUserDto, BindingResult bindingResult){
        if(bindingResult.hasErrors())
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        if(userService.existByUsername(newUserDto.getCodigo()))
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        if(userService.existByIdentification(newUserDto.getIdentificacion()))
            return new ResponseEntity<>(HttpStatus.BAD_REQUEST);

        User user = new User(newUserDto.getCodigo(),passwordEncoder.encode(newUserDto.getPassword()),newUserDto.getIdentificacion(),
                newUserDto.getApellido1(),newUserDto.getApellido2(),newUserDto.getNombre1(),newUserDto.getNombre2(),true);

        user.setRol(rolService.getByRolName(RolName.ADMINISTRADOR).get());
        userService.save(user);
        return new ResponseEntity(HttpStatus.CREATED);
    }

    @PostMapping("/login")
    public ResponseEntity<JwtDto> login (@Valid @RequestBody LoginUserDto loginUserDto,BindingResult bindingResult){
        if(bindingResult.hasErrors())
            return new ResponseEntity(HttpStatus.BAD_REQUEST);
        Authentication authentication =
                authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(loginUserDto.getUsername(),loginUserDto.getPassword())) ;
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwt = jwtProvider.generateToken(authentication);
        UserPrincipal userPrincipal = (UserPrincipal) authentication.getPrincipal();
        String refreshToken = jwtProvider.generateRefreshToken(authentication);
        JwtDto jwtDto = new JwtDto(jwt,userPrincipal.getUsername(),refreshToken,userPrincipal.isFirstTry(), userPrincipal.getAuthorities());
        return new ResponseEntity(jwtDto,HttpStatus.OK);
    }


    @PostMapping("/updatePass")
    public ResponseEntity<?> update(@Valid @RequestBody UpdatePassDto updatePassDto, BindingResult bindingResult){
        if(bindingResult.hasErrors()) return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
        User user = userService.getByUsername(updatePassDto.getUsername()).get();
        user.setPassword(passwordEncoder.encode(updatePassDto.getPassword()));
        user.setFirstTry(false);
        userService.save(user);
        return new ResponseEntity(new MessageDTO("Password actualizado"),HttpStatus.ACCEPTED);
    }

    @PostMapping("/refreshToken")
    public ResponseEntity<?> refreshToken(@Valid @RequestBody RefreshTokenDTO refreshTokenDTO){
        Map<Object, Object> model = new HashMap<>();
        String usernameToken = jwtProvider.getUsernameFromToken(refreshTokenDTO.getRefreshToken());
        if (!usernameToken.equals(refreshTokenDTO.getUsername())) {
            return new ResponseEntity(HttpStatus.UNAUTHORIZED);
        }
        else {
        Authentication authentication = jwtProvider.getAuthentication(refreshTokenDTO.getRefreshToken());
        String token = jwtProvider.generateToken(authentication);
        model.put("token", token);
        return ok(model);
        }
    }
}
