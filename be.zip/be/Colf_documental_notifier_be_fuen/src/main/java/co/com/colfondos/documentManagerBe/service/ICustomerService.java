package co.com.colfondos.documentManagerBe.service;


import co.com.colfondos.documentManagerBe.dto.request.NewRequestDTO;
import co.com.colfondos.documentManagerBe.dto.response.CustomerInformationAnswerDTO;
import co.com.colfondos.documentManagerBe.dto.response.MessageDTO;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface ICustomerService {

  ResponseEntity<List<CustomerInformationAnswerDTO>> getByIdentification(String... filter);

  ResponseEntity<MessageDTO> saveIdentification(NewRequestDTO newRequest);
}
