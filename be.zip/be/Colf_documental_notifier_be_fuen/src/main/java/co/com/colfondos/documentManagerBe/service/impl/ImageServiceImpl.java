package co.com.colfondos.documentManagerBe.service.impl;

import co.com.colfondos.documentManagerBe.common.service.BaseService;
import co.com.colfondos.documentManagerBe.model.Images;
import co.com.colfondos.documentManagerBe.model.Request;
import co.com.colfondos.documentManagerBe.repository.IImagesRepository;
import co.com.colfondos.documentManagerBe.service.IImageService;
import co.com.colfondos.documentManagerBe.service.IRequestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;


@Service
@Slf4j
public class ImageServiceImpl extends BaseService implements IImageService {

  @Autowired
  private IImagesRepository imageRepository;

  @Autowired
  private IRequestService requestService;

  @Override
  public List<Images> saveListImages(List<Images> images) {
    if(images.size() > 1){
      Request request = requestService.saveRequest(images.get(0).getCodsol());
      images.forEach(i -> i.setCodsol(request));
    }
    return imageRepository.saveAll(images);
  }
}
