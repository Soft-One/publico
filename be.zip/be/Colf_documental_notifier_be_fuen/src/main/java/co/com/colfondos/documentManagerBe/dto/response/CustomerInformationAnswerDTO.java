package co.com.colfondos.documentManagerBe.dto.response;

import co.com.colfondos.documentManagerBe.dto.ImagesDTO;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@NoArgsConstructor
public class CustomerInformationAnswerDTO {

  private String affiliationNumber;
  private String fullName;
  private String preCaptureDate;
  private String statePO;
  private String stateCE;
  private List<ImagesDTO> images;
  private String originData;
  public CustomerInformationAnswerDTO(String affiliationNumber, String fullName, String preCaptureDate,
                                      String statePO, String stateCE, List<ImagesDTO> images, String originData) {
    this.affiliationNumber =  affiliationNumber;
    this.fullName = fullName;
    this.preCaptureDate = preCaptureDate;
    this.statePO = statePO;
    this.stateCE = stateCE;
    this.images = images;
    this.originData = originData;
  }
}
