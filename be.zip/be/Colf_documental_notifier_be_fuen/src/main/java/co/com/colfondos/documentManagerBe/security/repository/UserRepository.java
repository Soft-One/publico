package co.com.colfondos.documentManagerBe.security.repository;

import co.com.colfondos.documentManagerBe.security.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User, Integer> {
    Optional<User> findByCodigo (String codigo);
    boolean existsByCodigo (String codigo);
    boolean existsByIdentificacion (String identification);
}
