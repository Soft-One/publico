package co.com.colfondos.documentManagerBe.security.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UpdatePassDto {
    private String username;
    private String password;
}
