package co.com.colfondos.documentManagerBe.common.service;


import co.com.colfondos.documentManagerBe.exception.GeneralException;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;

@Slf4j
public abstract class BaseService {

  protected void throwFailure(Throwable f) {
    String failureMessage = f.getMessage();
    log.error("Failed: " + f.getMessage() + " - Cause: " + f.getCause());
    if (null != failureMessage) {
      if (failureMessage.contains(String.valueOf(HttpStatus.BAD_REQUEST.value()))) {
        throw new GeneralException(HttpStatus.BAD_REQUEST.value(), f.getMessage());
      } else if (failureMessage.contains(String.valueOf(HttpStatus.UNAUTHORIZED.value()))) {
        throw new GeneralException(HttpStatus.UNAUTHORIZED.value(), f.getMessage());
      } else {
        throw new GeneralException(HttpStatus.INTERNAL_SERVER_ERROR.value(), f.getMessage());
      }
    }
    throw new GeneralException(HttpStatus.INTERNAL_SERVER_ERROR.value(), f.getMessage());
  }
}
