package co.com.colfondos.documentManagerBe.dto.mapper;



import co.com.colfondos.documentManagerBe.dto.StatesCfgDTO;
import co.com.colfondos.documentManagerBe.model.StatesCfg;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;




@Mapper(componentModel="spring")
public interface StatesCfgMapper {
  StatesCfgMapper INSTANCE = Mappers.getMapper(StatesCfgMapper.class);
  StatesCfgDTO statesCfgToStatesCfgDTO(StatesCfg statesCfg);
}
