package co.com.colfondos.documentManagerBe.repository;

import co.com.colfondos.documentManagerBe.model.Customer;
import co.com.colfondos.documentManagerBe.model.Request;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ICustomerRepository extends JpaRepository<Customer, Integer> {

  List<Customer> findByIdentificacionAndTipoIdentificacion(String identification, int typeIdentification);

  List<Customer> findByRequests(Request request);

}
