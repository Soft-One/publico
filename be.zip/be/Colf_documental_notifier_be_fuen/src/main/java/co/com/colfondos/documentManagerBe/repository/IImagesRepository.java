package co.com.colfondos.documentManagerBe.repository;

import co.com.colfondos.documentManagerBe.model.Images;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IImagesRepository extends JpaRepository<Images, Integer> {

}
