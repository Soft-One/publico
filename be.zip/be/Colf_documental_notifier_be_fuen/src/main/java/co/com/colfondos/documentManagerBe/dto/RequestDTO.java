package co.com.colfondos.documentManagerBe.dto;


import lombok.Getter;
import lombok.Setter;

import java.util.List;


@Getter
@Setter
public class RequestDTO {

  private long codsol;

  private CustomerDTO codigo;

  private java.sql.Timestamp fechaCreacion;

  private StatesCfgDTO estadopo;

  private StatesCfgDTO estadoce;

  private String numeroSolicitud;

  private List<ImagesDTO> images;



}
