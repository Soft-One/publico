package co.com.colfondos.documentManagerBe.security.enums;

public enum RolName {
    ADMINISTRADOR,
    OPERACIONES,
    BACKOFFICE,
    CUSTODIA,
    DIRECTOR_COMERCIAL,
    GERENTE_REGIONAL,
    SUPERVISOR,
    RADICADOR,
    CONTROL,
    INFORMES,
    CONSULTAS,
    JEFE_OPERACIONES,
    SEGURIDAD_USUARIOS
    }
