package co.com.colfondos.documentManagerBe.service.impl;

import co.com.colfondos.documentManagerBe.common.service.BaseService;
import co.com.colfondos.documentManagerBe.model.Request;
import co.com.colfondos.documentManagerBe.repository.IRequestRepository;
import co.com.colfondos.documentManagerBe.service.IRequestService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class RequestServiceImpl extends BaseService implements IRequestService {

  @Autowired
  private IRequestRepository requestRepository;

  @Override
  public Request getByNumeroSolicitud(String solicitud) {
    return requestRepository.findByNumeroSolicitud(solicitud);
  }

  @Override
  public Request saveRequest(Request request) {
    return requestRepository.save(request);
  }

}
