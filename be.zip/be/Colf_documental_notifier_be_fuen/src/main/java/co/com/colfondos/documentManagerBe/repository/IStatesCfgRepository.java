package co.com.colfondos.documentManagerBe.repository;

import co.com.colfondos.documentManagerBe.model.StatesCfg;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IStatesCfgRepository extends JpaRepository<StatesCfg, Integer> {

}
