package co.com.colfondos.documentManagerBe.security.repository;

import co.com.colfondos.documentManagerBe.security.entity.Rol;
import co.com.colfondos.documentManagerBe.security.enums.RolName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RolRepository extends JpaRepository<Rol, Integer> {
Optional<Rol> findByDescripcion (RolName rolName);
}
