package co.com.colfondos.documentManagerBe.dto.mapper;


import co.com.colfondos.documentManagerBe.dto.ImagesDTO;
import co.com.colfondos.documentManagerBe.model.Images;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;

import java.util.List;


@Mapper(componentModel="spring")
public interface ImagesMapper {
  ImagesMapper INSTANCE = Mappers.getMapper(ImagesMapper.class);
  List<Images> listImagesDTOToImages(List<ImagesDTO> imagesDTO);
}
