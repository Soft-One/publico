package co.com.colfondos.documentManagerBe.dto;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ImagesDTO {

  private long consecutivo;

  @JsonIgnore
  private long codigo;

  private RequestDTO codsol;

  private java.sql.Timestamp fechaAlta;

  private String usuario;

  private long tipoDocumento;

  private byte[] imagen;

  private String nombreImagen;

  private String tipoarchivo;

}
