package co.com.colfondos.documentManagerBe.dto.mapper;


import co.com.colfondos.documentManagerBe.dto.RequestDTO;
import co.com.colfondos.documentManagerBe.model.Request;
import org.mapstruct.Mapper;
import org.mapstruct.factory.Mappers;


@Mapper(componentModel="spring")
public interface RequestMapper {
  RequestMapper INSTANCE = Mappers.getMapper(RequestMapper.class);
  Request requestDTOToRequest(RequestDTO requestDTO);
}
