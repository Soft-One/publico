package co.com.colfondos.documentManagerBe.exception;

import co.com.colfondos.documentManagerBe.dto.response.MessageDTO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;


@RestControllerAdvice
public class MainHandler extends ResponseEntityExceptionHandler {

  @ExceptionHandler(value = {GeneralException.class})
  public final ResponseEntity handleConflict(RuntimeException ex) {
    GeneralException exc = (GeneralException) ex;
    if (exc.getStatus() == HttpStatus.BAD_REQUEST.value()) {
      logger.error("message"+exc.getMessage());
      logger.error(ex.toString());
      return ResponseEntity.badRequest().build();
    } else if (exc.getStatus() == HttpStatus.UNAUTHORIZED.value()) {
      return new ResponseEntity<>(HttpStatus.UNAUTHORIZED);
    } else if (exc.getStatus() == HttpStatus.CONFLICT.value()) {
      return ResponseEntity.ok(new MessageDTO(exc.getMessage()));
    } else  if (exc.getStatus() == HttpStatus.NOT_FOUND.value()) {
      return new ResponseEntity<>(HttpStatus.NOT_FOUND);
    } else {
      return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
    }
  }

}
