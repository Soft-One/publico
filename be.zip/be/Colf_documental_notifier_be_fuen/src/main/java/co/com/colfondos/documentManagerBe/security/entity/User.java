package co.com.colfondos.documentManagerBe.security.entity;

import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "TAB_USU")
@Getter
@Setter
public class User {

    @Id
    @Column(name = "codigo")
    private String codigo;
    @Column(name = "password")
    private String password;
    @Column(name = "identificacion")
    private String identificacion;
    @Column(name = "apellido1")
    private String apellido1;
    @Column(name = "apellido2")
    private String apellido2;
    @Column(name = "nombre1")
    private String nombre1;
    @Column(name = "nombre2")
    private String nombre2;
    @Column(name = "primer_ingreso")
    private boolean firstTry;
    @OneToOne
    @JoinColumn(name = "rol")
    private Rol rol;

    public User() {
    }

    public User(String codigo,String password, String identificacion, String apellido1, String apellido2,
                String nombre1,String nombre2,boolean firstTry) {
        this.codigo = codigo;
        this.password = password;
        this.identificacion = identificacion;
        this.apellido1 = apellido1;
        this.apellido2 = apellido2;
        this.nombre1 = nombre1;
        this.nombre2 = nombre2;
        this.firstTry = firstTry;
    }
}
