package co.com.colfondos.documentManagerBe.dto;


import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
public class CustomerDTO {


  private long codigo;

  private java.sql.Timestamp fechaCreacion;

  private String usuario;

  private String identificacion;

  private int tipoIdentificacion;

  private String nombre1;

  private String nombre2;

  private String apellido1;

  private String apellido2;

  private java.sql.Timestamp fechaNacimiento;

  private String ciudadNacimiento;

  private String nacionalidad;

  private java.sql.Timestamp fechaExpedicion;

  private String ciudadExpedicion;

  private String sexo;

  private String renta;

  private String celular;

  private String email;

  private String borrado;

  private String nacionalidad2;

  private String nacionalidad3;

  private List<RequestDTO> requests;

}
