package co.com.colfondos.documentManagerBe.repository;

import co.com.colfondos.documentManagerBe.model.Request;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IRequestRepository extends JpaRepository<Request, Integer> {

  Request findByNumeroSolicitud(String numeroSolicitud);

}
