package co.com.colfondos.documentManagerBe.service.impl;

import co.com.colfondos.documentManagerBe.common.service.BaseService;
import co.com.colfondos.documentManagerBe.dto.StatesCfgDTO;

import co.com.colfondos.documentManagerBe.dto.mapper.StatesCfgMapper;
import co.com.colfondos.documentManagerBe.repository.IStatesCfgRepository;
import co.com.colfondos.documentManagerBe.service.IStatesCfgService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class StatesCfgServiceImpl extends BaseService implements IStatesCfgService {

  @Autowired
  private IStatesCfgRepository statesCfgRepository;


  @Override
  public StatesCfgDTO getById(Integer id){
    return StatesCfgMapper.INSTANCE.statesCfgToStatesCfgDTO(statesCfgRepository.findById(id).orElse(null));
  }

}
