package co.com.colfondos.documentManagerBe.dto.mapper;


import co.com.colfondos.documentManagerBe.dto.CustomerDTO;
import co.com.colfondos.documentManagerBe.dto.ImagesDTO;
import co.com.colfondos.documentManagerBe.dto.RequestDTO;
import co.com.colfondos.documentManagerBe.model.Customer;
import co.com.colfondos.documentManagerBe.model.Images;
import co.com.colfondos.documentManagerBe.model.Request;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

import java.util.List;


@Mapper(componentModel="spring")
public interface CustomerMapper {
  CustomerMapper INSTANCE = Mappers.getMapper(CustomerMapper.class);


  List<CustomerDTO> listCustomerToListCustomerDto(List<Customer> customer);

  @Mapping(target = "codigo", ignore = true)
  RequestDTO requestToRequestDTO(Request request);

  @Mapping(target = "codsol", ignore = true)
  ImagesDTO imagesToImagesDTO(Images images);
}
