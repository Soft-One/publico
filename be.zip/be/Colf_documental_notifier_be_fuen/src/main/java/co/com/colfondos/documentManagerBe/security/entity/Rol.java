package co.com.colfondos.documentManagerBe.security.entity;

import co.com.colfondos.documentManagerBe.security.enums.RolName;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "TAB_ROL")
@Getter
@Setter
public class Rol {
    @Id
    @Column(name = "codigo")
    private long codigo;

    @Enumerated(EnumType.STRING)
    @Column(name = "descripcion")
    private RolName descripcion;

    public Rol() {
    }

    public Rol(RolName descripcion) {
        this.descripcion = descripcion;
    }
}
