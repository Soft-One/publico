package co.com.colfondos.documentManagerBe.constants;

public final class ResourceMapping {
    private ResourceMapping() {}
    public static final String ROOT = "/document-manager";
    public static final String CUSTOMER =  "/customer";
    public static final String GET_INFORMATION = "/getInformationByIdentification";
    public static final String SAVE_INFORMATION = "/saveInformation";
}
