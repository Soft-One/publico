package co.com.colfondos.documentManagerBe.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class StatesCfgDTO {


  private long id;

  private String descripcion;

  private String activo;

  private String validopo;

  private String validoce;

  private String ver;

  private long orden;

}
