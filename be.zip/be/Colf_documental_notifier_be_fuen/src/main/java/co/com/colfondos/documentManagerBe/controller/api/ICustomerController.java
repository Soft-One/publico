package co.com.colfondos.documentManagerBe.controller.api;


import co.com.colfondos.documentManagerBe.constants.ResourceMapping;
import co.com.colfondos.documentManagerBe.dto.request.NewRequestDTO;
import co.com.colfondos.documentManagerBe.dto.response.CustomerInformationAnswerDTO;
import co.com.colfondos.documentManagerBe.dto.response.MessageDTO;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import io.swagger.annotations.ApiParam;

import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;

import java.util.List;


@Validated
@Api(tags = ResourceMapping.ROOT + ResourceMapping.CUSTOMER)
public interface ICustomerController {
    @ApiOperation(
            value = "",
            notes = "This operation get the customer information with associated images",
            response = CustomerInformationAnswerDTO.class
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok")
            ,
            @ApiResponse(code = 500, message = "Internal error")
    })
    ResponseEntity<List<CustomerInformationAnswerDTO>> getByIdentification(
            @ApiParam(name = "identification", value = "This value refers to the identification number")
            String identification,
            @ApiParam(name = "typeIdentification", value = "This value refers to the type identification (cc,ce,passport...)")
            String typeIdentification,
            @ApiParam(name = "affiliationNumber", value = "This value refers to the affiliation number")
            String affiliationNumber
    );

    @ApiOperation(
            value = "",
            notes = "This operation save the customer information with associated images",
            response = MessageDTO.class
    )
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Ok")
            ,
            @ApiResponse(code = 500, message = "Internal error")
    })
    ResponseEntity<MessageDTO> saveIdentification(
            @ApiParam(name = "newRequestDTO", value = "This value refers to the new request")
                    NewRequestDTO newRequest
    );
}
