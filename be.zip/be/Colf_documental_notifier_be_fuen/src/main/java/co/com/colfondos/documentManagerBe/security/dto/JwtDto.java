package co.com.colfondos.documentManagerBe.security.dto;

import lombok.Getter;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;

import java.util.Collection;

@Getter
@Setter
public class JwtDto {
    private String token;
    private String bearer = "Bearer";
    private String username;
    private String refreshToken;
    private boolean firstTry;
    private Collection<? extends GrantedAuthority> authorities;

    public JwtDto(String token, String username, String refreshToken,boolean firstTry,
                  Collection<? extends GrantedAuthority> authorities) {
        this.token = token;
        this.username = username;
        this.refreshToken = refreshToken;
        this.firstTry = firstTry;
        this.authorities = authorities;
    }
}
