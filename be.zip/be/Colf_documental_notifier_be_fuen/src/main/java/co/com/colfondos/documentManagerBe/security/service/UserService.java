package co.com.colfondos.documentManagerBe.security.service;

import co.com.colfondos.documentManagerBe.security.entity.User;
import co.com.colfondos.documentManagerBe.security.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Optional;

@Service
@Transactional
public class UserService {

    @Autowired
    UserRepository userRepository;

    public Optional<User> getByUsername(String username){
        return userRepository.findByCodigo(username);
    }

    public boolean existByUsername(String username){
        return userRepository.existsByCodigo(username);
    }

    public boolean existByIdentification(String identification){
        return userRepository.existsByIdentificacion(identification);
    }

    public void save(User user){
        userRepository.save(user);
    }
}
