package co.com.colfondos.documentManagerBe.dto.mapper.response;


import co.com.colfondos.documentManagerBe.dto.CustomerDTO;
import co.com.colfondos.documentManagerBe.dto.ImagesDTO;
import co.com.colfondos.documentManagerBe.dto.RequestDTO;
import co.com.colfondos.documentManagerBe.dto.StatesCfgDTO;
import co.com.colfondos.documentManagerBe.dto.mapper.CustomerMapper;
import co.com.colfondos.documentManagerBe.dto.mapper.ImagesMapper;
import co.com.colfondos.documentManagerBe.dto.request.NewRequestDTO;
import co.com.colfondos.documentManagerBe.dto.response.CustomerInformationAnswerDTO;
import co.com.colfondos.documentManagerBe.exception.GeneralException;
import co.com.colfondos.documentManagerBe.model.Customer;
import co.com.colfondos.documentManagerBe.model.Images;
import io.vavr.control.Option;
import org.springframework.http.HttpStatus;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class CustomerInformationAnswerMapper {

private CustomerInformationAnswerMapper() { throw new IllegalStateException("CustomerInformationAnswerMapper class");}

public static List<CustomerInformationAnswerDTO> listCustomerToListCustomerInformationAnswerDTO(List<Customer> customer) {

        List<CustomerInformationAnswerDTO> customerList = null;
        Option.of(customer.get(0).getCodigo()).getOrElseThrow(()
        -> new GeneralException(HttpStatus.NOT_FOUND.value(), "NOT Found"));

        List<CustomerDTO> listCustomerDto = CustomerMapper.INSTANCE.listCustomerToListCustomerDto(customer);

        for(CustomerDTO custom : listCustomerDto){
            customerList = custom.getRequests().stream().map(temp -> {
            return new CustomerInformationAnswerDTO(
            temp.getNumeroSolicitud(),
            custom.getNombre1() + " " + custom.getNombre2() + " " + custom.getApellido1() + " " + custom.getApellido2(),
            String.valueOf(temp.getFechaCreacion()).substring(0, 10),
            (temp.getEstadoce() != null) ? temp.getEstadoce().getDescripcion() : null,
            (temp.getEstadopo() != null) ? temp.getEstadopo().getDescripcion() : null,
            (temp.getImages() != null) ? temp.getImages():null,
            null);
            }).collect(Collectors.toList());
        }
        return customerList;
}

public static List<Images> newRequestDTOToImages(NewRequestDTO newRequestDTO, StatesCfgDTO statesCfgDto) {
    final Supplier<GeneralException> not_found = () -> new GeneralException(HttpStatus.NOT_FOUND.value(), "NOT Found");
    Option.of(newRequestDTO).getOrElseThrow(not_found);
    Option.of(statesCfgDto).getOrElseThrow(not_found);
    Date date = new Date();
    List<ImagesDTO> imagesDTOList = new ArrayList<>();
    if(newRequestDTO != null) {
        CustomerDTO customerDTO = new CustomerDTO();
        customerDTO.setNombre1(newRequestDTO.getFirstName());
        customerDTO.setNombre2(newRequestDTO.getMiddleName());
        customerDTO.setApellido1(newRequestDTO.getLastName());
        customerDTO.setApellido2(newRequestDTO.getSurName());
        customerDTO.setUsuario("prueba01");
        customerDTO.setIdentificacion(newRequestDTO.getDocumentNumber());
        customerDTO.setTipoIdentificacion(newRequestDTO.getDocumentType());
        customerDTO.setFechaCreacion(new java.sql.Timestamp(date.getTime()));
        customerDTO.setFechaNacimiento(new java.sql.Timestamp(date.getTime()));
        RequestDTO requestDTO = new RequestDTO();
        if(newRequestDTO.getRequestNumber() != null){
            requestDTO.setNumeroSolicitud(newRequestDTO.getRequestNumber());
            requestDTO.setEstadoce(statesCfgDto);
            requestDTO.setEstadopo(statesCfgDto);
            requestDTO.setFechaCreacion(new java.sql.Timestamp(date.getTime()));
            requestDTO.setCodigo(customerDTO);
        }
        if(!newRequestDTO.getImages().isEmpty()){
            for(ImagesDTO imagesDTOL: newRequestDTO.getImages()) {
                ImagesDTO imagesDTO = new ImagesDTO();
                imagesDTO.setFechaAlta(new java.sql.Timestamp(date.getTime()));
                imagesDTO.setNombreImagen(imagesDTOL.getNombreImagen());
                imagesDTO.setTipoDocumento(1);
                imagesDTO.setImagen(imagesDTOL.getImagen());
                imagesDTO.setTipoarchivo(imagesDTOL.getTipoarchivo());
                imagesDTO.setCodsol(requestDTO);
                imagesDTOList.add(imagesDTO);
            }
        }
    }
        return ImagesMapper.INSTANCE.listImagesDTOToImages(imagesDTOList);
    }


}
