package co.com.colfondos.documentManagerBe.controller;


import co.com.colfondos.documentManagerBe.constants.ResourceMapping;
import co.com.colfondos.documentManagerBe.controller.api.ICustomerController;
import co.com.colfondos.documentManagerBe.dto.response.CustomerInformationAnswerDTO;
import co.com.colfondos.documentManagerBe.dto.response.MessageDTO;
import co.com.colfondos.documentManagerBe.dto.request.NewRequestDTO;
import co.com.colfondos.documentManagerBe.service.ICustomerService;
import io.swagger.annotations.Api;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


import java.util.List;

@RestController
@Slf4j
@RequestMapping(ResourceMapping.ROOT + ResourceMapping.CUSTOMER)
@Api(tags =  ResourceMapping.ROOT + ResourceMapping.CUSTOMER)
public class CustomerController implements ICustomerController {

  @Autowired
  private ICustomerService service;

  @CrossOrigin
  @GetMapping(ResourceMapping.GET_INFORMATION)
  @Override
  public ResponseEntity<List<CustomerInformationAnswerDTO>> getByIdentification(String identification,String typeIdentification,String affiliationNumber) {
    return service.getByIdentification(identification,typeIdentification,affiliationNumber);
  }

  @CrossOrigin
  @PostMapping(ResourceMapping.SAVE_INFORMATION)
  @Override
  public ResponseEntity<MessageDTO> saveIdentification(@RequestBody NewRequestDTO newRequest) {
    return service.saveIdentification(newRequest);
  }
}
