package co.com.colfondos.documentManagerBe.security.dto;

import lombok.Getter;
import lombok.Setter;

import java.util.HashSet;
import java.util.Set;

@Getter
@Setter
public class NewUserDto {
    private String codigo;
    private String password;
    private String identificacion;
    private String apellido1;
    private String apellido2;
    private String nombre1;
    private String nombre2;
    private Set<String> rol = new HashSet<>();
}
