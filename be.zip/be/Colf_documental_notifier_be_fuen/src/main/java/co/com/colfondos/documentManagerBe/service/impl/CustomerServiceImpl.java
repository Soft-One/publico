package co.com.colfondos.documentManagerBe.service.impl;

import co.com.colfondos.documentManagerBe.common.service.BaseService;
import co.com.colfondos.documentManagerBe.constants.MessageConstant;
import co.com.colfondos.documentManagerBe.dto.mapper.response.CustomerInformationAnswerMapper;
import co.com.colfondos.documentManagerBe.dto.request.NewRequestDTO;
import co.com.colfondos.documentManagerBe.dto.response.CustomerInformationAnswerDTO;
import co.com.colfondos.documentManagerBe.dto.response.MessageDTO;
import co.com.colfondos.documentManagerBe.exception.GeneralException;
import co.com.colfondos.documentManagerBe.model.Customer;
import co.com.colfondos.documentManagerBe.repository.ICustomerRepository;
import co.com.colfondos.documentManagerBe.service.ICustomerService;
import co.com.colfondos.documentManagerBe.service.IImageService;
import co.com.colfondos.documentManagerBe.service.IRequestService;
import co.com.colfondos.documentManagerBe.service.IStatesCfgService;
import io.vavr.control.Try;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


@Service
@Slf4j
public class CustomerServiceImpl extends BaseService implements ICustomerService {

  @Autowired
  private ICustomerRepository customerRepository;

  @Autowired
  private IStatesCfgService statesCfgservice;

  @Autowired
  private IRequestService requestService;

  @Autowired
  private IImageService imageservice;

  @Override
  public ResponseEntity<List<CustomerInformationAnswerDTO>> getByIdentification(String... filter) {
    Try<List<Customer>> tryCustomerInquiry;

    if (filter[2] == null) {
      tryCustomerInquiry = Try
              .of(() -> customerRepository.
                      findByIdentificacionAndTipoIdentificacion(filter[0], Integer.parseInt(filter[1])));
    }else{
      tryCustomerInquiry = Try
              .of(() -> customerRepository.
                      findByRequests(requestService.getByNumeroSolicitud(filter[2])));
    }
    return ResponseEntity.ok(
            CustomerInformationAnswerMapper.listCustomerToListCustomerInformationAnswerDTO (tryCustomerInquiry.getOrElse(ArrayList::new)));
  }

  @Override
  public ResponseEntity<MessageDTO> saveIdentification(NewRequestDTO newRequest){
      Try.of( () -> {
        imageservice.saveListImages(
                CustomerInformationAnswerMapper.newRequestDTOToImages(newRequest, statesCfgservice.getById(1)));
        log.info(MessageConstant.SAVE_OK);
        return ResponseEntity.ok(new MessageDTO(MessageConstant.SAVE_OK));
      })
      .onFailure(f -> {
        String message = (f.getMessage().contains("constraint")) ? MessageConstant.SAVE_KO_DUPLICATE :MessageConstant.SAVE_KO;
        throw new GeneralException(HttpStatus.CONFLICT.value(), message);
      });
    return ResponseEntity.ok(new MessageDTO(MessageConstant.SAVE_OK));
  }
}
