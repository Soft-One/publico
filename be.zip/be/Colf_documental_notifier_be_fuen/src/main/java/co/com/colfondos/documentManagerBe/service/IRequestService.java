package co.com.colfondos.documentManagerBe.service;


import co.com.colfondos.documentManagerBe.model.Request;

public interface IRequestService {

  Request getByNumeroSolicitud(String solicitud);

  Request saveRequest(Request request);
}
