package co.com.colfondos.documentManagerBe.constants;

public final class MessageConstant {
    public static final String SAVE_OK = "Se a guardado exitosamente";
    public static final String SAVE_KO = "Error al guardar la informacion";
    public static final String SAVE_KO_DUPLICATE = "Error registro duplicado";
}
