package co.com.colfondos.documentManagerBe.model;


import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name = "Cli_Basico")
@Getter
@Setter
public class Customer {

  @Id
  @GeneratedValue(strategy = GenerationType.TABLE, generator = "book_generator")
  @TableGenerator(name="book_generator", table="id_generator", initialValue = 875000)
  private long codigo;

  @Column(name = "fechaCreacion")
  private java.sql.Timestamp fechaCreacion;

  @Column(name = "usuario")
  private String usuario;

  @Column(name = "identificacion")
  private String identificacion;

  @Column(name = "tipoIdentificacion")
  private int tipoIdentificacion;

  @Column(name = "nombre1")
  private String nombre1;

  @Column(name = "nombre2")
  private String nombre2;

  @Column(name = "apellido1")
  private String apellido1;

  @Column(name = "apellido2")
  private String apellido2;

  @Column(name = "fechaNacimiento")
  private java.sql.Timestamp fechaNacimiento;

  @Column(name = "ciudadNacimiento")
  private String ciudadNacimiento;

  @Column(name = "nacionalidad")
  private String nacionalidad;

  @Column(name = "fechaExpedicion")
  private java.sql.Timestamp fechaExpedicion;

  @Column(name = "ciudadExpedicion")
  private String ciudadExpedicion;

  @Column(name = "sexo")
  private String sexo;

  @Column(name = "renta")
  private String renta;

  @Column(name = "celular")
  private String celular;

  @Column(name = "email")
  private String email;

  @Column(name = "borrado")
  private String borrado;

  @Column(name = "nacionalidad2")
  private String nacionalidad2;

  @Column(name = "nacionalidad3")
  private String nacionalidad3;

  @OneToMany(mappedBy="codigo",cascade =  CascadeType.ALL, orphanRemoval = true)
  private List<Request> requests;

}
