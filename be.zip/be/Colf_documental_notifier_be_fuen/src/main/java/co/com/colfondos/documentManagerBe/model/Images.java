package co.com.colfondos.documentManagerBe.model;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Getter;
import lombok.Setter;

import javax.persistence.*;

@Entity
@Table(name = "IMAGENES")
@Getter
@Setter
public class Images {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  @Column(name = "consecutivo")
  private long consecutivo;

  @JsonIgnore
  @Column(name="codigo")
  private long codigo;

  @ManyToOne(cascade =  CascadeType.ALL,fetch=FetchType.LAZY)
  @JoinColumn(name = "codsol")
  private Request codsol;

  @Column(name = "fechaAlta")
  private java.sql.Timestamp fechaAlta;

  @Column(name = "usuario")
  private String usuario;

  @Column(name = "tipoDocumento")
  private long tipoDocumento;

  @Lob
  @Column(name = "imagen")
  private byte[] imagen;

  @Column(name = "nombreImagen")
  private String nombreImagen;

  @Column(name = "tipoarchivo")
  private String tipoarchivo;

}
