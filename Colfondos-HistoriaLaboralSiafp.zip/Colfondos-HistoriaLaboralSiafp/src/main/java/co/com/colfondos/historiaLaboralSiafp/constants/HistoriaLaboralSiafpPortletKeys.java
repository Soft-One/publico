package co.com.colfondos.historiaLaboralSiafp.constants;

/**
 * @author JH28537
 */
public class HistoriaLaboralSiafpPortletKeys {

	public static final String HISTORIALABORALSIAFP =
		"co_com_colfondos_historiaLaboralSiafp_HistoriaLaboralSiafpPortlet";

}